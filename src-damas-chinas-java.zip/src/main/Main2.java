package main;



import gui.DamasGui;
import ai.AiPlayer0Handler;
import ai.AiPlayer1Handler;
import logic.DamasGame;
import logic.Piece;

public class Main2{
    public static void main(String[] args) {
        // first we create the game
        DamasGame damasGame = new DamasGame();

        // then we create the clients/players
        DamasGui damasGui = new DamasGui(damasGame);
        AiPlayer1Handler aiPlayer1Handler = new AiPlayer1Handler(damasGame, 1);
        AiPlayer0Handler aiPlayer0Handler = new AiPlayer0Handler(damasGame, 2);

        // then we attach the clients/players to the game
        damasGame.setPlayer(Piece.COLOR_YELLOW, aiPlayer0Handler);
        damasGame.setPlayer(Piece.COLOR_BLUE, aiPlayer1Handler);
        //damasGame.setPlayer(Piece.COLOR_WHITE, damasGui);
        damasGame.setPlayer(Piece.COLOR_NONE, damasGui);
 
        // in the end we start the game
        new Thread(damasGame).start();
    }
    
}
