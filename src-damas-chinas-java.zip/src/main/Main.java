package main;

import ai.AiPlayer0Handler;
import ai.AiPlayer1Handler;
import gui.DamasGui;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import logic.DamasGame;
import logic.Piece;

public class Main implements ActionListener {
    private String p0 = "ial2";
    private String p1 = "ial2";
     
    Main() {
        JFrame f = new JFrame("Damas Chinas");
        f.setSize(220, 200);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JMenuBar jmb = new JMenuBar();

        JMenu jmFile = new JMenu("File");
        JMenuItem jmiStart = new JMenuItem("Start");
        JMenuItem jmiExit = new JMenuItem("Exit");
        jmFile.add(jmiStart);
        jmFile.addSeparator();
        jmFile.add(jmiExit);
        jmb.add(jmFile);

        JMenu jmOptions = new JMenu("Options");
        JMenu a = new JMenu("Player 1");
        JRadioButtonMenuItem jRadioButtonMenu1 = new JRadioButtonMenuItem("P1 IA L2");
        JRadioButtonMenuItem jRadioButtonMenu2 = new JRadioButtonMenuItem("P1 IA L3");
        JRadioButtonMenuItem jRadioButtonMenu3 = new JRadioButtonMenuItem("P1 IA L4");
        JRadioButtonMenuItem jRadioButtonMenu4 = new JRadioButtonMenuItem("P1 Human");
        ButtonGroup grupoRadios = new ButtonGroup();
        grupoRadios.add(jRadioButtonMenu1);
        grupoRadios.add(jRadioButtonMenu2);
        grupoRadios.add(jRadioButtonMenu3);
        grupoRadios.add(jRadioButtonMenu4);
        a.add(jRadioButtonMenu1);
        a.add(jRadioButtonMenu2);
        a.add(jRadioButtonMenu3);
        a.add(jRadioButtonMenu4);
        jRadioButtonMenu1.setSelected(true);
        jmOptions.add(a);

        JMenu e = new JMenu("Player 2");
        JRadioButtonMenuItem jRadioButtonMenu5 = new JRadioButtonMenuItem("P2 IA L1");
        JRadioButtonMenuItem jRadioButtonMenu6 = new JRadioButtonMenuItem("P2 IA L2");
        JRadioButtonMenuItem jRadioButtonMenu7 = new JRadioButtonMenuItem("P2 IA L3");
        JRadioButtonMenuItem jRadioButtonMenu8 = new JRadioButtonMenuItem("P2 Human");
        ButtonGroup grupoRadios2 = new ButtonGroup();
        grupoRadios2.add(jRadioButtonMenu5);
        grupoRadios2.add(jRadioButtonMenu6);
        grupoRadios2.add(jRadioButtonMenu7);
        grupoRadios2.add(jRadioButtonMenu8);
        e.add(jRadioButtonMenu5);
        e.add(jRadioButtonMenu6);
        e.add(jRadioButtonMenu7);
        e.add(jRadioButtonMenu8);
        jRadioButtonMenu6.setSelected(true);
        jmOptions.add(e);

        jmb.add(jmOptions);

        JMenu jmHelp = new JMenu("Help");
        JMenuItem jmiAbout = new JMenuItem("About");
        jmHelp.add(jmiAbout);
        jmb.add(jmHelp);

        jmiStart.addActionListener(this);
        jmiExit.addActionListener(this);
        jmiAbout.addActionListener(this);
        jRadioButtonMenu1.addActionListener(this);
        jRadioButtonMenu2.addActionListener(this);
        jRadioButtonMenu3.addActionListener(this);
        jRadioButtonMenu4.addActionListener(this);
        jRadioButtonMenu5.addActionListener(this);
        jRadioButtonMenu6.addActionListener(this);
        jRadioButtonMenu7.addActionListener(this);
        jRadioButtonMenu8.addActionListener(this);

        f.setJMenuBar(jmb);
        f.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        String comStr = ae.getActionCommand();
        //System.out.println(comStr + " Selected");
        switch(comStr){
            case "Exit":
                System.exit(0);
                break;
            case "Start":
                // first we create the game
                DamasGame damasGame = new DamasGame();
                // then we create the clients/players
                DamasGui damasGui = new DamasGui(damasGame);
                
                switch(p0){
                    case "ial2":
                        damasGame.setPlayer(Piece.COLOR_YELLOW, new AiPlayer0Handler(damasGame, 2));
                        break;
                    case "ial3":
                        damasGame.setPlayer(Piece.COLOR_YELLOW, new AiPlayer0Handler(damasGame, 3));
                        break;
                    case "ial4":
                        damasGame.setPlayer(Piece.COLOR_YELLOW, new AiPlayer0Handler(damasGame, 4));
                        break;
                    case "human":
                        damasGame.setPlayer(Piece.COLOR_YELLOW, damasGui);
                        break;                        
                }

                switch(p1){
                    case "ial1":
                        damasGame.setPlayer(Piece.COLOR_BLUE, new AiPlayer1Handler(damasGame, 1));
                        break;
                    case "ial2":
                        damasGame.setPlayer(Piece.COLOR_BLUE, new AiPlayer1Handler(damasGame, 2));
                        break;
                    case "ial3":
                        damasGame.setPlayer(Piece.COLOR_BLUE, new AiPlayer1Handler(damasGame, 3));
                        break;
                    case "human":
                        damasGame.setPlayer(Piece.COLOR_BLUE, damasGui);
                        break;                      
                }
                // watcher
                damasGame.setPlayer(Piece.COLOR_NONE, damasGui);
                // in the end we start the game
                new Thread(damasGame).start();
                break;
            case "P1 IA L2":
                p0 = "ial2";
                break;
            case "P1 IA L3":
                p0 = "ial3";
                break;
            case "P1 IA L4":
                p0 = "ial4";
                break;
            case "P1 Human":
                p0 = "human";
                break;
            case "P2 IA L1":
                p1 = "ial1";
                break;
            case "P2 IA L2":
                p1 = "ial2";
                break;
            case "P2 IA L3":
                p1 = "ial3";
                break;
            case "P2 Human":
                p1 = "human";
                break;
        }
    }
  public static void main(String args[]) {
    new Main();
  }
}