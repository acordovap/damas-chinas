package ai;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import logic.DamasGame;
import logic.IPlayerHandler;
import logic.Move;
import logic.Piece;

public class AiPlayer1Handler implements IPlayerHandler{

    private DamasGame damasGame;
    private List<Move> moves;
    private int level;
    
    public AiPlayer1Handler(DamasGame damasGame, int level){
        this.damasGame = damasGame;
        this.moves = new ArrayList<Move>();
        this.level = level;
        writeLevelToFile();
    }
    
    @Override
    public Move getMove() {
        if (this.moves.isEmpty())
            getLispMove();
        return this.moves.remove(0);
    }

    @Override
    public void moveSuccessfullyExecuted(Move move) {
        System.out.println("executed: "+move);
    }
    
    public void getLispMove(){
        writeBoardToFile();
        lispProc();
        readMovesFromFile();
    }
    
    public void lispProc(){
        Process p;
        try {
            p = Runtime.getRuntime().exec("cmd /c start /WAIT /min mulisp\\callDamas1.bat" );
            p.waitFor();            
        } catch (IOException | InterruptedException ex) {
            System.out.println("Error: " + ex.toString());
        }
    }
    
    public void readMovesFromFile(){
        try {
            String sCurrentLine;
            BufferedReader br = new BufferedReader(new FileReader("mulisp\\moves.txt"));
            
            while ((sCurrentLine = br.readLine()) != null) {
                String []move = sCurrentLine.replaceAll("\\(", "").replaceAll("\\)", "").split(" ");
                this.moves.add(new Move(Integer.parseInt(move[0]), Integer.parseInt(move[1]), Integer.parseInt(move[2]), Integer.parseInt(move[3])));
            }

        } catch (IOException ex) {
            System.out.println("Error: " + ex.toString());
        }
    }
    
    public void writeLevelToFile(){
        PrintWriter writer;
        try {
            writer = new PrintWriter("mulisp\\levelP1.txt");
            writer.println(this.level);
            writer.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.toString());
        }
    }
    
    public void writeBoardToFile(){
        List <Piece> pieces = this.damasGame.getPieces();
        Collections.shuffle(pieces, new Random(System.nanoTime()));
        PrintWriter writer;
        try {
            writer = new PrintWriter("mulisp\\pieces.txt");
            for (Piece piece : pieces) {
                writer.println("( " + piece.getQ() + " " + piece.getR() + " " + piece.getColor() + " )");
            }
            writer.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.toString());
        }
    }
}
