package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import logic.DamasGame;
import logic.IPlayerHandler;
import logic.Piece;
import logic.Move;
import logic.MoveValidator;

/**
 * all x and y coordinates point to the upper left position of a component all
 * lists are treated as 0 being the bottom and size-1 being the top piece
 * 
 */
public class DamasGui extends JPanel implements IPlayerHandler{

    private static final long serialVersionUID = 3114147670071466558L;

    private static final int BOARD_CENTER_X = 305;
    private static final int BOARD_CENTER_Y = 302;

    private static final double HEX_SIZE = 21.5;
    private static final double HEX_HEIGHT = HEX_SIZE * 2;
    private static final double HEX_WIDTH = Math.sqrt(3)/2 * HEX_HEIGHT;
    
    private Image imgBackground;
    private JLabel lblGameState;

    private DamasGame damasGame;
    private List<GuiPiece> guiPieces = new ArrayList<GuiPiece>();
   
    private GuiPiece dragPiece; // currently dragged game piece
    private Move lastMove; // the last executed move (used for highlighting)
    private Move currentMove;
    
    private boolean draggingGamePiecesEnabled;

    public DamasGui(DamasGame damasGame) {
        this.setLayout(null);
        
        // load and set background image
        
        URL urlBackgroundImg = getClass().getResource("img\\board.png");
        this.imgBackground = new ImageIcon(urlBackgroundImg).getImage();

        // create damas game
        this.damasGame = damasGame;
        
        //wrap game pieces into their graphical representation
        for (Piece piece : this.damasGame.getPieces()) {
            createAndAddGuiPiece(piece);
        }
        
        // add mouse listeners to enable drag and drop
        //
        PiecesDragAndDropListener listener = new PiecesDragAndDropListener(this.guiPieces, this);
        this.addMouseListener(listener);
        this.addMouseMotionListener(listener);

        // button to change game state
        //JButton btnChangeGameState = new JButton("change");
        //btnChangeGameState.addActionListener(new ChangeGameStateButtonActionListener(this));
        //btnChangeGameState.setBounds(0, 0, 80, 30);
        //this.add(btnChangeGameState);

        // label to display game state
        String labelText = this.getGameStateAsText();
        this.lblGameState = new JLabel(labelText);
        lblGameState.setBounds(10, 30, 80, 30);
        lblGameState.setForeground(Color.BLACK);
        this.add(lblGameState);
        
        // create application frame and set visible
        JFrame f = new JFrame(); try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                damasGame.endGame();
            }
        });
        f.setVisible(true);
        //f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(this);
        f.setResizable(false);
        f.setSize(this.imgBackground.getWidth(null), this.imgBackground.getHeight(null));
    }

    /**
     * @return textual description of current game state
     */
    private String getGameStateAsText() {
        String state = "unknown";
        switch (this.damasGame.getGameState()) {
            case DamasGame.GAME_STATE_BLUE: state = "blue turn";break;
            case DamasGame.GAME_STATE_END: state = "end";break;
            case DamasGame.GAME_STATE_YELLOW: state = "yellow turn";break;
        }
        return state;
    }
    
    /**
     * create a game piece
     * 
     * @param color color constant
     * @param x x position of upper left corner
     * @param y y position of upper left corner
     */
    private void createAndAddGuiPiece(Piece piece) {
        Image img = this.getImageForPiece(piece.getColor());
        GuiPiece guiPiece = new GuiPiece(img, piece);
        this.guiPieces.add(guiPiece);
    }

    /**
     * load image for given color and type. This method translates the color and
     * type information into a filename and loads that particular file.
     * 
     * @param color color constant
     * @return image
     */
    private Image getImageForPiece(int color) {
        String filename = "";
        
        switch (color) {
            case Piece.COLOR_BLUE:
                filename += "bp";
                break;
            case Piece.COLOR_YELLOW:
                filename += "yp";
                break;
        }
        filename += ".png";

        URL urlPieceImg = getClass().getResource("img//" + filename);
        return new ImageIcon(urlPieceImg).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(this.imgBackground, 0, 0, null);
        for (GuiPiece guiPiece : this.guiPieces) {
            g.drawImage(guiPiece.getImage(), guiPiece.getX(), guiPiece.getY(), null);
        }
        
        if( !isUserDraggingPiece() && this.lastMove != null ){
            int highlightSourceX = convertQRToX(this.lastMove.sourceQ, this.lastMove.sourceR);
            int highlightSourceY = convertQRToY(this.lastMove.sourceQ, this.lastMove.sourceR);
            int highlightTargetX = convertQRToX(this.lastMove.targetQ, this.lastMove.targetR);
            int highlightTargetY = convertQRToY(this.lastMove.targetQ, this.lastMove.targetR);

            g.setColor(Color.RED);
            g.fillOval(highlightSourceX-6+(int)HEX_WIDTH/2, highlightSourceY-7+(int)HEX_HEIGHT/2, 10, 10);
            g.fillOval(highlightTargetX-6+(int)HEX_WIDTH/2, highlightTargetY-7+(int)HEX_HEIGHT/2, 10, 10);
        }
        
        if( isUserDraggingPiece() ){
			
            MoveValidator moveValidator = this.damasGame.getMoveValidator();

            int sourceQ, sourceR;
            
            sourceQ = this.dragPiece.getPiece().getQ();
            sourceR = this.dragPiece.getPiece().getR();
            
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ+1, sourceR-1)) > -1 ){
                int highlightX = convertQRToX(sourceQ+1, sourceR-1);
                int highlightY = convertQRToY(sourceQ+1, sourceR-1);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ+1, sourceR)) > -1 ){
                int highlightX = convertQRToX(sourceQ+1, sourceR);
                int highlightY = convertQRToY(sourceQ+1, sourceR);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ, sourceR+1)) > -1 ){
                int highlightX = convertQRToX(sourceQ, sourceR+1);
                int highlightY = convertQRToY(sourceQ, sourceR+1);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ-1, sourceR+1)) > -1 ){
                int highlightX = convertQRToX(sourceQ-1, sourceR+1);
                int highlightY = convertQRToY(sourceQ-1, sourceR+1);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ-1, sourceR)) > -1 ){
                int highlightX = convertQRToX(sourceQ-1, sourceR);
                int highlightY = convertQRToY(sourceQ-1, sourceR);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ, sourceR-1)) > -1 ){
                int highlightX = convertQRToX(sourceQ, sourceR-1);
                int highlightY = convertQRToY(sourceQ, sourceR-1);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
//
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ+2, sourceR-2)) > -1 ){
                int highlightX = convertQRToX(sourceQ+2, sourceR-2);
                int highlightY = convertQRToY(sourceQ+2, sourceR-2);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ+2, sourceR)) > -1 ){
                int highlightX = convertQRToX(sourceQ+2, sourceR);
                int highlightY = convertQRToY(sourceQ+2, sourceR);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ, sourceR+2)) > -1 ){
                int highlightX = convertQRToX(sourceQ, sourceR+2);
                int highlightY = convertQRToY(sourceQ, sourceR+2);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ-2, sourceR+2)) > -1 ){
                int highlightX = convertQRToX(sourceQ-2, sourceR+2);
                int highlightY = convertQRToY(sourceQ-2, sourceR+2);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ-2, sourceR)) > -1 ){
                int highlightX = convertQRToX(sourceQ-2, sourceR);
                int highlightY = convertQRToY(sourceQ-2, sourceR);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }
            if( moveValidator.isMoveValid( new Move(sourceQ, sourceR, sourceQ, sourceR-2)) > -1 ){
                int highlightX = convertQRToX(sourceQ, sourceR-2);
                int highlightY = convertQRToY(sourceQ, sourceR-2);
                
                g.setColor(Color.GREEN);
                g.fillOval(highlightX-6+(int)HEX_WIDTH/2, highlightY-7+(int)HEX_HEIGHT/2, 10, 10);
            }

        }
        
        this.lblGameState.setText(this.getGameStateAsText());
    }

    /** 
     * @return true if user is currently dragging a game piece
     */
    private boolean isUserDraggingPiece() {
        return this.dragPiece != null;
    }  
    
    public static void main(String[] args) {
        //new DamasGui();
        DamasGame damasGame = new DamasGame();
        DamasGui damasGui = new DamasGui(damasGame);
        damasGame.setPlayer(Piece.COLOR_YELLOW, damasGui);
        damasGame.setPlayer(Piece.COLOR_BLUE, damasGui);
        new Thread(damasGame).start();
    }
    
     /**
     * @return current game state
     */
    public int getGameState() {
        return this.damasGame.getGameState();
    }
    
    public static int convertQRToX(int q, int r){
        return (int) Math.round(HEX_SIZE * Math.sqrt(3) * (q + (double)r/2) + BOARD_CENTER_X);
    }
    
    public static int convertQRToY(int q, int r){
        return (int) Math.round((double)3/2 * r * HEX_SIZE + BOARD_CENTER_Y);
    }
    
    public static int convertXYToQ(int x, int y){
        return (int) Math.round( ((x-BOARD_CENTER_X) * Math.sqrt(3)/3 - (y-BOARD_CENTER_Y) / 3) / HEX_SIZE);
    }

    public static int convertXYToR(int x, int y){
        return (int) Math.round((y-BOARD_CENTER_Y) * 2/3 / (double)HEX_SIZE);
    }
    
   public void setNewPieceLocation(GuiPiece dragPiece, int x, int y) {
        int targetQ = DamasGui.convertXYToQ(x, y);
        int targetR = DamasGui.convertXYToR(x, y);
        
        Move move = new Move(dragPiece.getPiece().getQ(), dragPiece.getPiece().getR(), targetQ, targetR);
        
        if( this.damasGame.getMoveValidator().isMoveValid(move) > -1 ){
            this.currentMove = move;
        }else{
            dragPiece.resetToUnderlyingPiecePosition();
        }
/**
        if( false){
            // reset piece position if move is not valid
            dragPiece.resetToUnderlyingPiecePosition();

        }else{
            //change model and update gui piece afterwards
            System.out.println("moving piece to "+targetQ+"/"+targetR);
            Move move = new Move(dragPiece.getPiece().getQ(), dragPiece.getPiece().getR(), targetQ, targetR);
            boolean wasMoveSuccessfull = this.damasGame.movePiece( move );
            
            // if the last move was successfully executed, we remember it for
            // highlighting it in the user interface
            if( wasMoveSuccessfull ){
                this.lastMove = move;
            }
            dragPiece.resetToUnderlyingPiecePosition();
        }
**/
    } 
   
    @Override
    public Move getMove() {
        this.draggingGamePiecesEnabled = true; 
        Move moveForExecution = this.currentMove;
        this.currentMove = null;
        return moveForExecution;
    }

    @Override
    public void moveSuccessfullyExecuted(Move move) {
        // adjust GUI piece
        GuiPiece guiPiece = this.getGuiPieceAt(move.targetQ, move.targetR);
        if( guiPiece == null){
                throw new IllegalStateException("no guiPiece at "+move.targetQ+"/"+move.targetR);
        }
        guiPiece.resetToUnderlyingPiecePosition();

        // remember last move
        this.lastMove = move;

        // disable dragging until asked by ChessGame for the next move
        this.draggingGamePiecesEnabled = false;

        // repaint the new state
        this.repaint();
    }  
    
    public boolean isDraggingGamePiecesEnabled(){
        return draggingGamePiecesEnabled;
    }    
    
    /**
     * get non-captured the gui piece at the specified position
     * @param q
     * @param r
     * @return the gui piece at the specified position, null if there is no piece
     */
    private GuiPiece getGuiPieceAt(int q, int r) {
        for (GuiPiece guiPiece : this.guiPieces) {
            if( guiPiece.getPiece().getQ() == q
                            && guiPiece.getPiece().getR() == r){
                    return guiPiece;
            }
        }
        return null;
    }  
        
    /**
     * @param guiPiece - set the gui piece that the user is current dragging
     */
    public void setDragPiece(GuiPiece guiPiece) {
        this.dragPiece = guiPiece;
    }

    /**
     * @return the gui piece that the user is currently dragging
     */
    public GuiPiece getDragPiece(){
        return this.dragPiece;
    }
    
    public void windowClosing(WindowEvent e){
        
    }
    
}
