package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChangeGameStateButtonActionListener implements ActionListener {

    private DamasGui damasGui;

    public ChangeGameStateButtonActionListener(DamasGui damasGui) {
        this.damasGui = damasGui;
    }

    @Override
    public void actionPerformed(ActionEvent evt) {
        //change game state if button is pressed
        //this.damasGui.changeGameState();
    }
}