package logic;

public class Piece {
    
    private int color;
    public static final int COLOR_NONE = -1;
    public static final int COLOR_YELLOW = 0;
    public static final int COLOR_BLUE = 1;
    
    //For axial coord
    private int q;
    private int r;

    public Piece(int q, int r, int color) {
        this.color = color;
        this.q = q;
        this.r = r;
    }

    public int getQ() {
        return q;
    }

    public int getR() {
        return r;
    }

    public void setQ(int q) {
        this.q = q;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getColor() {
	return this.color;
    }
	
    @Override
    public String toString() {
        String strColor = "unknowColor";
        switch (this.color) {
            case COLOR_BLUE: strColor = "black";break;
            case COLOR_YELLOW: strColor = "white";break;
        }
        String strQ = String.valueOf(this.r);
        String strR = String.valueOf(this.q);
        return strColor+" Q> "+strQ+" R> "+strR;
    }

}
