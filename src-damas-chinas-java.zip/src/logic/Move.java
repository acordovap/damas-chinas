package logic;

public class Move {
    public int sourceQ;
    public int sourceR;
    public int targetQ;
    public int targetR;

    public Move(int sourceQ, int sourceR, int targetQ, int targetR) {
        this.sourceQ = sourceQ;
        this.sourceR = sourceR;
        this.targetQ = targetQ;
        this.targetR = targetR;
    }
    
    @Override
    public String toString(){
        StringBuffer sb = new StringBuffer();
        sb.append(this.sourceQ+","+this.sourceR+"\t ->\t "+this.targetQ+","+this.targetR);
        return sb.toString();
    }
}