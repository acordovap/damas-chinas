package logic;

import java.util.ArrayList;
import java.util.Arrays;

public class MoveValidator {

    private DamasGame damasGame;
    private Piece sourcePiece;
    private Piece targetPiece;
    private ArrayList<ArrayList<Integer>> board;

    public MoveValidator(DamasGame damasGame){
        this.damasGame = damasGame;
        board= new ArrayList<>();
        for(int q=-4; q < 5; q++){
            for(int r=-4; r < 5; r++){
                board.add(new ArrayList<>(Arrays.asList(new Integer[] { q, r })));
            }
        }
        for(int q=-8; q < -4; q++){
            for(int r=-q-4; r < 5; r++){
                board.add(new ArrayList<>(Arrays.asList(new Integer[] { q, r })));
            }
        }
        for(int q=-4; q < 0; q++){
            for(int r=5; r < 5-q; r++){
                board.add(new ArrayList<>(Arrays.asList(new Integer[] { q, r })));
            }
        }
        for(int q=1; q < 5; q++){
            for(int r=-q-4; r < -4; r++){
                board.add(new ArrayList<>(Arrays.asList(new Integer[] { q, r })));
            }
        }
        for(int q=5; q < 9; q++){
            for(int r=-4; r < 5-q; r++){
                board.add(new ArrayList<>(Arrays.asList(new Integer[] { q, r })));
            }
        }
    }

    /**
     * Checks if the specified move is valid
     * @param move
     * @return -1 no valid, 0 valid, 1 valid and jump
     */
    public int isMoveValid(Move move) {
        
        int sourceQ = move.sourceQ;
        int sourceR = move.sourceR;
        int targetQ = move.targetQ;
        int targetR = move.targetR;

        sourcePiece = this.damasGame.getPieceAtLocation(sourceQ, sourceR);
        targetPiece = this.damasGame.getPieceAtLocation(targetQ, targetR);

        // source piece does not exist
        if( sourcePiece == null ){
            System.out.println("no source piece");
            return -1;
        }

        // source piece has right color?
        if( sourcePiece.getColor() == Piece.COLOR_YELLOW
            && this.damasGame.getGameState() == DamasGame.GAME_STATE_YELLOW){
            // ok
        }else if( sourcePiece.getColor() == Piece.COLOR_BLUE
            && this.damasGame.getGameState() == DamasGame.GAME_STATE_BLUE){
            // ok
        }else{
            //System.out.println("it's not your turn");
            return -1;
        }

        // check if target location within boundaries
        if( !board.contains(new ArrayList<>(Arrays.asList(new Integer[] { targetQ, targetR })))){
            //System.out.println("Out of scope");
            return -1;
        }

        // validate piece movement rules
        int validPieceMove = isValidMove(sourceQ, sourceR, targetQ,targetR);

        return validPieceMove;
    }

    private boolean isTargetLocationFree() {
        return targetPiece == null;
    }

        /**
     * Checks if the specified move is valid
     * @param sourceQ
     * @param sourceR
     * @param targetQ
     * @param targetR
     * @return -1 no valid, 0 valid, 1 valid and jump
     */
    private int isValidMove(int sourceQ, int sourceR, int targetQ, int targetR) {
        int isValid = -1;
        Move lastMove = this.damasGame.getLastMove();
          
        if(this.damasGame.isLastMoveJump() && lastMove != null )
            if(lastMove.targetQ == sourceQ && lastMove.targetR == sourceR){
                if(sourceQ == targetQ && sourceR == targetR)
                        return 0;
                if( isTargetLocationFree()){
                    if(sourceQ+2 == targetQ && sourceR-2 == targetR && arePieceAtLocation(sourceQ+1, sourceR-1))
                        return 1;
                    else if(sourceQ+2 == targetQ && sourceR == targetR && arePieceAtLocation(sourceQ+1, sourceR))
                        return 1;
                    else if(sourceQ == targetQ && sourceR+2 == targetR && arePieceAtLocation(sourceQ, sourceR+1))
                        return 1;
                    else if(sourceQ-2 == targetQ && sourceR+2 == targetR && arePieceAtLocation(sourceQ-1, sourceR+1))
                        return 1;
                    else if(sourceQ-2 == targetQ && sourceR == targetR && arePieceAtLocation(sourceQ-1, sourceR))
                        return 1;
                    else if(sourceQ == targetQ && sourceR-2 == targetR && arePieceAtLocation(sourceQ, sourceR-1))
                        return 1;
                }
                return -1;
            }
            else
                return -1;
        
        // target location possible?
        if( isTargetLocationFree()){
            if(sourceQ+1 == targetQ && sourceR-1 == targetR)
                isValid = 0;
            else if(sourceQ+1 == targetQ && sourceR == targetR)
                isValid = 0;
            else if(sourceQ == targetQ && sourceR+1 == targetR)
                isValid = 0;
            else if(sourceQ-1 == targetQ && sourceR+1 == targetR)
                isValid = 0;
            else if(sourceQ-1 == targetQ && sourceR == targetR)
                isValid = 0;
            else if(sourceQ == targetQ && sourceR-1 == targetR)
                isValid = 0;//
            else if(sourceQ+2 == targetQ && sourceR-2 == targetR && arePieceAtLocation(sourceQ+1, sourceR-1))
                isValid = 1;
            else if(sourceQ+2 == targetQ && sourceR == targetR && arePieceAtLocation(sourceQ+1, sourceR))
                isValid = 1;
            else if(sourceQ == targetQ && sourceR+2 == targetR && arePieceAtLocation(sourceQ, sourceR+1))
                isValid = 1;
            else if(sourceQ-2 == targetQ && sourceR+2 == targetR && arePieceAtLocation(sourceQ-1, sourceR+1))
                isValid = 1;
            else if(sourceQ-2 == targetQ && sourceR == targetR && arePieceAtLocation(sourceQ-1, sourceR))
                isValid = 1;
            else if(sourceQ == targetQ && sourceR-2 == targetR && arePieceAtLocation(sourceQ, sourceR-1))
                isValid = 1;
            else{
                //System.out.println("no valid location");
                isValid = -1;
            }
        }else{
            //System.out.println("target location not free");
            return -1;
        }

        return isValid;
    }
    
    private boolean arePieceAtLocation(int targetQ, int targetR) {
        if( this.damasGame.getPieceAtLocation(targetQ, targetR) != null){
            return true;
        }
        return false;
    }
        
}
