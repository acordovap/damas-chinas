package logic;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DamasGame implements Runnable{
	
    private int gameState = GAME_STATE_YELLOW;
    private boolean isLastMoveJump = false;
    private Move lastMove = null;
    private boolean ended = false;
    public static final int GAME_STATE_YELLOW = 0;
    public static final int GAME_STATE_BLUE = 1;
    public static final int GAME_STATE_END = -1;
    
    // 0 = bottom, size = top
    private List<Piece> pieces = new ArrayList<Piece>();

    private MoveValidator moveValidator;
    private IPlayerHandler viewPlayerHandler;
    private IPlayerHandler blackPlayerHandler;
    private IPlayerHandler whitePlayerHandler;
    private IPlayerHandler activePlayerHandler;
    
    /**
     * initialize game
     */
    public DamasGame(){
        
        this.moveValidator = new MoveValidator(this);
        // first player
        createAndAddPiece(-4, 8, Piece.COLOR_YELLOW);
        createAndAddPiece(-3, 7, Piece.COLOR_YELLOW);
        createAndAddPiece(-4, 7, Piece.COLOR_YELLOW);
        createAndAddPiece(-2, 6, Piece.COLOR_YELLOW);
        createAndAddPiece(-3, 6, Piece.COLOR_YELLOW);
        createAndAddPiece(-4, 6, Piece.COLOR_YELLOW);
        createAndAddPiece(-1, 5, Piece.COLOR_YELLOW);
        createAndAddPiece(-2, 5, Piece.COLOR_YELLOW);
        createAndAddPiece(-3, 5, Piece.COLOR_YELLOW);
        createAndAddPiece(-4, 5, Piece.COLOR_YELLOW);
        
        // second player
        createAndAddPiece(4, -8, Piece.COLOR_BLUE);
        createAndAddPiece(3, -7, Piece.COLOR_BLUE);
        createAndAddPiece(4, -7, Piece.COLOR_BLUE);
        createAndAddPiece(2, -6, Piece.COLOR_BLUE);
        createAndAddPiece(3, -6, Piece.COLOR_BLUE);
        createAndAddPiece(4, -6, Piece.COLOR_BLUE);
        
        createAndAddPiece(1, -5, Piece.COLOR_BLUE);
        createAndAddPiece(2, -5, Piece.COLOR_BLUE);
        createAndAddPiece(3, -5, Piece.COLOR_BLUE);
        createAndAddPiece(4, -5, Piece.COLOR_BLUE);
        
    }

    /**
     * create piece instance and add it to the internal list of pieces
     * 
     * @param color on of Pieces.COLOR_..
     * @param q on of Piece_..
     * @param r on of Pieces..
     */
    private void createAndAddPiece(int q, int r, int color) {
        Piece piece = new Piece(q, r, color);
        this.pieces.add(piece);
    }

    /**
     * set the player/client for the specified piece color
     * @param pieceColor - the color the client/player controls
     * @param playerHandler - the player/client
     */
    public void setPlayer(int pieceColor, IPlayerHandler playerHandler){
        switch (pieceColor) {
            case Piece.COLOR_BLUE: this.blackPlayerHandler = playerHandler; break;
            case Piece.COLOR_YELLOW: this.whitePlayerHandler = playerHandler; break;
            case Piece.COLOR_NONE: this.viewPlayerHandler = playerHandler; break;
            default: throw new IllegalArgumentException("Invalid pieceColor: "+pieceColor);
        }
    }
    
    /**
     * start main game flow
     */
    public void startGame(){
        // check if all players are ready
        System.out.println("DamasGame: waiting for players");
        while (this.blackPlayerHandler == null || this.whitePlayerHandler == null || this.viewPlayerHandler == null){
            // players are still missing
            try {Thread.sleep(1000);} catch (InterruptedException e) {}
        }

        // set start player
        this.activePlayerHandler = this.whitePlayerHandler;
            
        // start game flow
        System.out.println("DamasGame: starting game flow");
        while(!isGameEndConditionReached() && !gameEnded()){
            waitForMove();
        }

        System.out.println("DamasGame: game ended");
    }    

    
    /**
     * wait for a valid player move and execute it
     */
    private void waitForMove() {
        long a = System.currentTimeMillis();
        Move move = null;
        // wait for a valid move
        do{
            move = this.activePlayerHandler.getMove();
            try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        }while(move == null || this.moveValidator.isMoveValid(move) < 0);

        //execute move
        boolean success = this.movePiece(move);
        try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
        if(success){
            this.blackPlayerHandler.moveSuccessfullyExecuted(move);
            this.whitePlayerHandler.moveSuccessfullyExecuted(move);
            this.viewPlayerHandler.moveSuccessfullyExecuted(move);
            swapActivePlayer();
        }else{
            throw new IllegalStateException("move was valid, but failed to execute it");
        }
        //System.out.println("Total time: " + (System.currentTimeMillis() - a)/1000);
    }
    
    /**
     * swap active player and update game state
     */
    private void swapActivePlayer() {
        this.changeGameState();
        if(this.gameState == GAME_STATE_YELLOW)
            this.activePlayerHandler = this.whitePlayerHandler;
        else
            this.activePlayerHandler = this.blackPlayerHandler;
        /**
        if( this.activePlayerHandler == this.whitePlayerHandler ){
            this.activePlayerHandler = this.blackPlayerHandler;
        }else{
            this.activePlayerHandler = this.whitePlayerHandler;
        }
        **/
    }    
    
    /**
     * Move piece to the specified location. If the target location is occupied
     * by an opponent piece, that piece is marked as 'captured'
     * @param move the move of the piece to move
     */
    public boolean movePiece(Move move) {
        int valMove = this.moveValidator.isMoveValid(move);
        if (valMove < 0) {
            System.out.println("move invalid");
            return false;
        }
        this.lastMove = move;
        if(valMove == 1)
            this.isLastMoveJump = true;
        else if(valMove == 0)
            this.isLastMoveJump = false;
        
        Piece piece = getPieceAtLocation(move.sourceQ, move.sourceR);

        piece.setQ(move.targetQ);
        piece.setR(move.targetR);
        /**
         * this was moved of place for flow
        if (isGameEndConditionReached()) {
            this.gameState = GAME_STATE_END;
        } else {
          this.changeGameState();
        }
        **/
        return true;
    }
    
    /**
     * check if the games end condition is met: all pieces in the other side
     * 
     * @return true if the game end condition is met
     */
    private boolean isGameEndConditionReached() {
        return yellowW() || blueW();
    }
        
    public boolean yellowW(){
        for (Piece piece : this.pieces) {
            if(piece.getColor() == piece.COLOR_YELLOW)
                if ( !( (piece.getQ() == 4 && piece.getR() == -8) ||
                    (piece.getQ() == 4 && piece.getR() == -7) ||
                    (piece.getQ() == 4 && piece.getR() == -6) ||
                    (piece.getQ() == 3 && piece.getR() == -7) ||
                    (piece.getQ() == 3 && piece.getR() == -6) ||
                    (piece.getQ() == 2 && piece.getR() == -6) ||
                    (piece.getQ() == 4 && piece.getR() == -5) ||
                    (piece.getQ() == 3 && piece.getR() == -5) ||
                    (piece.getQ() == 2 && piece.getR() == -5) ||
                    (piece.getQ() == 1 && piece.getR() == -5) ))
                return false;
        }
        return true;
    }
    
    public boolean blueW(){
        for (Piece piece : this.pieces) {
            if(piece.getColor() == piece.COLOR_BLUE)
                if ( !( (piece.getQ() == -4 && piece.getR() == 8) ||
                    (piece.getQ() == -4 && piece.getR() == 7) ||
                    (piece.getQ() == -4 && piece.getR() == 6) ||
                    (piece.getQ() == -3 && piece.getR() == 7) ||
                    (piece.getQ() == -3 && piece.getR() == 6) ||
                    (piece.getQ() == -2 && piece.getR() == 6) ||
                    (piece.getQ() == -4 && piece.getR() == 5) ||
                    (piece.getQ() == -3 && piece.getR() == 5) ||
                    (piece.getQ() == -2 && piece.getR() == 5) ||
                    (piece.getQ() == -1 && piece.getR() == 5) ))
                return false;
        }
        return true;
    }
    /**
     * returns the first piece at the specified location 
     * @param q one of Piece.q_..
     * @param r one of Piece.r_..
     * @return the first piece at the specified location
     */
    public Piece getPieceAtLocation(int q, int r) {
        //System.out.println("Buscando q="+q+" r="+r);
        for (Piece piece : this.pieces) {
            if( piece.getQ() == q && piece.getR() == r){
                return piece;
            }
        }
        return null;
    }
    
    public void setLastMoveJump(boolean isJump){
        this.isLastMoveJump = isJump;
    }
    
    public boolean isLastMoveJump(){
        return this.isLastMoveJump;
    }
    
    /**
     * @return current game state (one of DamasGame.GAME_STATE_..)
     */
    public int getGameState() {
        return this.gameState;
    }

    
    public boolean gameEnded(){
        return ended;
    }
    
    public void endGame(){
        this.ended = true;
    }
            
    public Move getLastMove(){
        return this.lastMove;
    }
    
    /**
     * @return the internal list of pieces
     */
    public List<Piece> getPieces() {
            return this.pieces;
    }

    public void changeGameState() {
        
        if (this.isGameEndConditionReached()) {

            if (this.gameState == DamasGame.GAME_STATE_BLUE) {
                System.out.println("Game over! Blue won!");
            } else {
                System.out.println("Game over! Yellow won!");
            }

            this.gameState = DamasGame.GAME_STATE_END;
            return;
        }
        
        if (!this.isLastMoveJump)
            switch (this.gameState) {
                case GAME_STATE_BLUE:
                    this.gameState = GAME_STATE_YELLOW;
                    break;
                case GAME_STATE_YELLOW:
                    this.gameState = GAME_STATE_BLUE;
                    break;
                default:
                    throw new IllegalStateException("unknown game state:" + this.gameState);
            }
    }

    public MoveValidator getMoveValidator(){
	return this.moveValidator;
    }
    
    @Override
    public void run() {
        this.startGame();
    }
    
            
}
